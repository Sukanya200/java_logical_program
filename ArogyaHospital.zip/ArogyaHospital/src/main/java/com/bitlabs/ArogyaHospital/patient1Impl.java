package com.bitlabs.ArogyaHospital;

import java.sql.*;

public class patient1Impl implements patient1Interface{

    Connection con=null;
	
    patient1Impl(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","bhuvi");    
            if(con!=null) {
                System.out.println("connection made sucessfully");
            }
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public void patientRegistration(patient1 P) {
        // TODO Auto-generated method stub
        
        try {
            PreparedStatement pstmt=con.prepareStatement("insert into patient1 values (?,?,?,?,?,?,?,?,?,?,?,?)");
            
			pstmt.setInt(1,P.getId());
            pstmt.setInt(2,P.getAge());
            pstmt.setString(3,P.getName());
            pstmt.setString(4,P.getGender());
            pstmt.setString(5,P.getCity());
            pstmt.setString(6,P.getAddress());
            pstmt.setString(7,P.getGuardian_name());
            pstmt.setString(8,P.getGuardian_address());
            pstmt.setString(9,P.getDateOfAdmission());
            pstmt.setLong(10,P.getAadhar_Card_number());
            pstmt.setLong(11,P.getContact_number());
            pstmt.setLong(12,P.getGuardian_contactNumber());
            
            int i=pstmt.executeUpdate();
            if(i!=0) {
                System.out.println("data saved sucessfully");
            }
            
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    public void viewAllpatient()
    {
    	try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT * FROM patient");
	        while(rs.next())
	         {
	         System.out.println(rs.getString(1) +"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12));
	         }
	       //con.close();
	     }
	     catch(Exception e) 
		{
	            System.out.println(e);
		}
    }
    public void searchpatientById(int id)
    {
    	try {
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("SELECT * FROM patient WHERE id="+id+"");
            rs.next();   
            System.out.println(rs.getString(1) +"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12));
           }
           catch(Exception e) {
               System.out.println(e);
           }
    }
    public void deletepatientById(int id)
    {
    	try
		{
			PreparedStatement pstmt=con.prepareStatement("DELETE FROM patient WHERE id="+id+"");
	        int i=pstmt.executeUpdate();
	        if(i==1)
	        {
	            System.out.println("Patient Record Deleted Successfully");                   
	        }
	        else
	        {
	            System.out.println("ERROR OCCUR WHILE Deleting");
	        }    
		}
		catch(Exception e) 
		{
            System.out.println(e);
        }
    }
    
 public void searchpatientByCity(String city)
    {
    	try
    	{
    		 Statement st=con.createStatement();

             ResultSet rs=st.executeQuery("SELECT * FROM patient WHERE city='"+city+"'");
             while(rs.next())
             {
             System.out.println(rs.getString(1) +"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12));
             }
                         
            }
            catch(SQLException e) {
                e.printStackTrace();
            }

      }
 public void searchPatientByAgeGroup(int start,int end)
 {
 	try
 	{
		 Statement st=con.createStatement();
      ResultSet rs=st.executeQuery("SELECT * FROM patient WHERE age>='"+start+"' && age<='"+end+"'");
      while(rs.next())
      {
      System.out.println(rs.getString(1) +"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12));
      }
                  
     }
     catch(SQLException e) {
         e.printStackTrace();
     }
 }

}