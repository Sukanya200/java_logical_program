package com.bitlabs.ArogyaHospital;

import java.util.Scanner;

public class App {

    

	public static void main(String [] args) {
    patient1Impl dao=new patient1Impl();
    patient1 p=new patient1();
    
    p.setId(110);
    p.setAge(23);
    p.setName("mohan");
    p.setGender("male");
    p.setCity("shrinivaspura");
    p.setAddress("4-5,kolar");
    p.setGuardian_name("pavan");
    p.setGuardian_address("4-5");
    p.setDateOfAdmission("1992/08/22");
    p.setAadhar_Card_number(123432);
    p.setContact_number(96189265);
    p.setGuardian_contactNumber(770236);
     Scanner sc = new Scanner(System.in);
    System.out.println("Choose your option");
    System.out.println("1.patientregistration 2.viewallpatient 3.searchpatientbyid 4.deletepatientbyid 5.searchpatientbycity 6.searchpatientbyagegroup");
    int n=sc.nextInt();
    switch(n)
    {
    case 1:
    	if(n==1)
         dao.patientRegistration(p);
    	break;
    case 2:
    	if(n==2)
          dao.viewAllpatient();
         break;
    case 3:
    	if(n==3)
         dao.searchpatientById(10);
         break;
    case 4:
    	if(n==4)
        dao.deletepatientById(10);
    	break;
    case 5:
    	if(n==5)
          dao.searchpatientByCity("kolar");
        break;
    case 6:
    	if(n==6)
          dao.searchPatientByAgeGroup(18, 55);
    	break;
    }
}
}

